import 'package:flutter/material.dart';

class Users extends StatelessWidget {
  const Users({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      "Users",
      style:TextStyle(
        fontFamily: "lora",
      )
    );
  }
}
