import 'package:flutter/material.dart';

class Notifications extends StatelessWidget {
  const Notifications({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      "Notifications",
      style:TextStyle(
        fontFamily: "lora",
      )
    );
  }
}
