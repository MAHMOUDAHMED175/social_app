import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:social_app/components/cache_helper.dart';
import 'package:social_app/components/constatnce.dart';
import 'package:social_app/layout/Social_Layout.dart';
import 'package:social_app/layout/cubit.dart';
import 'package:social_app/layout/states.dart';
import 'package:social_app/modules/social_login/login.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await CachHelper.initial();

  Widget widget;
  uid=CachHelper.getData(key: 'uid');
  if(uid !=null){
    widget=SocialLayout();
   }else{
    widget=SocialLogin();
   }
  runApp(MyApp(
    statrtWidget:widget,
  ));
}

class MyApp extends StatelessWidget {

  Widget statrtWidget;
  MyApp({
    @required this.statrtWidget,
});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
        return  MultiBlocProvider(
          providers: [
            BlocProvider(create: (BuildContext context)=>SocialLayoutCubit()..getPosts()..getUserData()..getAllUsers()

            ),
          ],
          child: BlocConsumer<SocialLayoutCubit,SocialLayoutStates>(
           listener:(context,state){},
           builder:(context,state){
             return MaterialApp(
             debugShowCheckedModeBanner: false,
             theme:ThemeData.light(),
    home:
     //SocialLayout(),
    statrtWidget,

    );
    },
          ),
        );
  }
}
